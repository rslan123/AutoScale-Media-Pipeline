export const authConfig = {
    Cognito: {
        userPoolId: 'eu-central-1_2SZgOuwi6',
        userPoolClientId: '718djbmlhpr4ta78d6qvdfa6m0',
        loginWith: {
            email: true
        }
    }
};