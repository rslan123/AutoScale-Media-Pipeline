// SizeComparison.jsx
import React from 'react';

const SizeComparison = ({ originalBytes, optimizedBytes }) => {
  // Logic: Calculate ratio for the bar width
  const ratio = (optimizedBytes / originalBytes) * 100;
  
  return (
    <div className="mt-8 space-y-2 p-4 bg-gray-50 rounded-xl border border-gray-200">
      <div className="flex justify-between text-xs font-bold text-gray-500 uppercase">
        <span>Original: {(originalBytes / 1024).toFixed(1)} KB</span>
        <span className="text-blue-600">Optimized: {(optimizedBytes / 1024).toFixed(1)} KB</span>
      </div>
      
      {/* The Bar */}
      <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className="h-full bg-blue-500 transition-all duration-1000 ease-out"
          style={{ width: `${ratio}%` }}
        />
      </div>
    </div>
  );
};

export default SizeComparison;